function goSearch(){const q=document.getElementById('globalSearch').value.trim();if(!q)return;location.href='quran.html?q='+encodeURIComponent(q)+'#tafsir';}
